package com.propiedades.main.propiedadFactoryException;

public class PropiedadException extends Exception{

    public PropiedadException(String message) {
        super(message);
    }
}
