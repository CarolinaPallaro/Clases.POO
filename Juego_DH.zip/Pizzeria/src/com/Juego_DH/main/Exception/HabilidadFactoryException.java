package com.Juego_DH.main.Exception;

public class HabilidadFactoryException extends Exception {

    public HabilidadFactoryException(String message) {
        super(message);
    }
}
