package Almacen2.pizzeriaException;

public class PizzeriaException extends Exception{

    public PizzeriaException(String message) {
        super(message);
    }
}
